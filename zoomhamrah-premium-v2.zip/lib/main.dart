import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const api = 'https://zoomhamrah.ir/wp-json/zoomhamrah/v1';
const blue = Color(0xFF123CF2);
const ink = Color(0xFF182230);
const muted = Color(0xFF667085);
const pageBg = Color(0xFFF5F7FB);

void main() => runApp(const ZoomHamrahApp());

class ZoomHamrahApp extends StatelessWidget {
  const ZoomHamrahApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'زوم همراه',
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: pageBg,
      colorScheme: ColorScheme.fromSeed(seedColor: blue, primary: blue),
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: ink, elevation: 0),
    ),
    home: const Directionality(textDirection: TextDirection.rtl, child: MainShell()),
  );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int tab = 0;
  final cart = <Map<String,dynamic>>[];
  List<Map<String,dynamic>> products = [];
  List<Map<String,dynamic>> categories = [];
  bool loading = true;
  String? error;
  int? categoryId;
  String search = '';

  @override void initState() { super.initState(); loadStore(); }

  Future<void> loadStore({int? category}) async {
    setState(() { loading = true; error = null; categoryId = category; });
    try {
      final query = <String,String>{'page':'1','per_page':'50'};
      if (category != null && category != 0) query['category'] = '$category';
      final responses = await Future.wait([
        http.get(Uri.parse('$api/products').replace(queryParameters: query)).timeout(const Duration(seconds: 25)),
        http.get(Uri.parse('$api/categories')).timeout(const Duration(seconds: 25)),
      ]);
      if (responses.any((r) => r.statusCode != 200)) throw Exception('server');
      final p = jsonDecode(utf8.decode(responses[0].bodyBytes)) as Map<String,dynamic>;
      final c = jsonDecode(utf8.decode(responses[1].bodyBytes)) as Map<String,dynamic>;
      if (p['success'] != true || c['success'] != true) throw Exception('api');
      if (!mounted) return;
      setState(() {
        products = List<Map<String,dynamic>>.from(p['products'] ?? []);
        categories = List<Map<String,dynamic>>.from(c['categories'] ?? []);
        loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() { loading = false; error = 'دریافت اطلاعات فروشگاه انجام نشد. اتصال اینترنت را بررسی کنید.'; });
    }
  }

  String price(dynamic raw) {
    final n = int.tryParse('$raw');
    if (n == null || n == 0) return 'استعلام قیمت';
    final s = n.toString();
    final b = StringBuffer();
    for (var i=0; i<s.length; i++) {
      b.write(s[i]);
      if ((s.length-i-1)%3==0 && i != s.length-1) b.write('٬');
    }
    return '${b.toString()} تومان';
  }

  List<Map<String,dynamic>> get shownProducts => products.where((p) =>
    search.trim().isEmpty || '${p['name']}'.toLowerCase().contains(search.trim().toLowerCase())
  ).toList();

  void add(Map<String,dynamic> p) {
    setState(() => cart.add(p));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('${p['name']} به سبد خرید اضافه شد'),
      behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 1),
    ));
  }

  @override Widget build(BuildContext context) {
    final pages = [
      homePage(),
      categoriesPage(),
      cartPage(),
      accountPage(),
    ];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        height: 68, backgroundColor: Colors.white, indicatorColor: const Color(0xFFE8EEFF),
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab=i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), selectedIcon: Icon(Icons.grid_view), label: 'دسته‌بندی'),
          NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), selectedIcon: Icon(Icons.shopping_bag), label: 'سبد خرید'),
          NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person), label: 'حساب من'),
        ],
      ),
    );
  }

  Widget topBar() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
    child: Row(children: [
      ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.asset('assets/images/zoomhamrah-logo.png', width: 44, height: 44, fit: BoxFit.cover)),
      const SizedBox(width: 10),
      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('زوم همراه', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: ink)),
        Text('فروشگاه آنلاین کالای دیجیتال', style: TextStyle(fontSize: 10, color: muted)),
      ])),
      IconButton(onPressed: () => setState(() => tab=2), icon: Badge(label: Text('${cart.length}'), child: const Icon(Icons.shopping_bag_outlined, color: ink))),
      IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded, color: ink)),
    ]),
  );

  Widget homePage() => RefreshIndicator(
    onRefresh: loadStore,
    child: CustomScrollView(slivers: [
      SliverToBoxAdapter(child: topBar()),
      SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: TextField(
          onChanged: (v)=>setState(()=>search=v),
          decoration: InputDecoration(
            hintText: 'جستجوی محصول، برند یا مدل...',
            prefixIcon: const Icon(Icons.search, color: muted),
            filled: true, fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(vertical: 14),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
        ),
      )),
      SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.fromLTRB(16,16,16,8),
        child: Container(
          height: 142, padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(begin: Alignment.topRight,end: Alignment.bottomLeft,colors:[Color(0xFF092BD4),Color(0xFF326BFF)]),
          ),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,mainAxisAlignment: MainAxisAlignment.center,children: const [
              Text('تجربه خریدی سریع و مطمئن',style:TextStyle(color:Colors.white,fontSize:17,fontWeight:FontWeight.w900)),
              SizedBox(height:8),
              Text('دنیای لوازم دیجیتال در زوم همراه',style:TextStyle(color:Colors.white,fontSize:11)),
            ])),
            const Icon(Icons.devices_rounded,color:Colors.white,size:62),
          ]),
        ),
      )),
      SliverToBoxAdapter(child: sectionTitle('دسته‌بندی‌های محبوب','مشاهده همه',()=>setState(()=>tab=1))),
      SliverToBoxAdapter(child: SizedBox(height: 112, child: loading
        ? const Center(child:SizedBox(width:22,height:22,child:CircularProgressIndicator(strokeWidth:2)))
        : ListView(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:12),children:
          categories.take(12).map((c)=>categoryTile(c, compact:true)).toList()))),
      SliverToBoxAdapter(child: sectionTitle('منتخب زوم همراه','همه محصولات',()=>setState(()=>tab=1))),
      if (loading) const SliverToBoxAdapter(child: Padding(padding:EdgeInsets.all(30),child:Center(child:CircularProgressIndicator())))
      else if (error != null) SliverToBoxAdapter(child: errorPanel())
      else if (shownProducts.isEmpty) const SliverToBoxAdapter(child: Padding(padding:EdgeInsets.all(28),child:Center(child:Text('محصولی پیدا نشد'))))
      else SliverPadding(
        padding: const EdgeInsets.fromLTRB(12,0,12,20),
        sliver: SliverGrid(
          delegate: SliverChildBuilderDelegate((ctx,i)=>productCard(shownProducts[i]),childCount:shownProducts.length),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,mainAxisSpacing:12,crossAxisSpacing:12,childAspectRatio:.62),
        ),
      ),
    ]),
  );

  Widget sectionTitle(String title,String action,VoidCallback onTap)=>Padding(
    padding:const EdgeInsets.fromLTRB(16,18,16,10),
    child:Row(children:[Text(title,style:const TextStyle(fontSize:15,fontWeight:FontWeight.w900,color:ink)),const Spacer(),TextButton(onPressed:onTap,child:Text(action,style:const TextStyle(fontSize:11)))]),
  );

  Widget categoryTile(Map<String,dynamic> c,{bool compact=false}) {
    final image = '${c['image'] ?? ''}';
    return GestureDetector(
      onTap: () { setState(()=>tab=1); loadStore(category: int.tryParse('${c['id']}')); },
      child: Container(
        width: compact?88: null, margin: const EdgeInsets.symmetric(horizontal:5),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16),border:Border.all(color:const Color(0xFFE9EDF4))),
        child: Column(mainAxisAlignment:MainAxisAlignment.center,children:[
          if(image.isNotEmpty) ClipRRect(borderRadius:BorderRadius.circular(12),child:Image.network(image,width:compact?48:64,height:compact?48:64,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Icon(Icons.category_outlined,color:blue,size:30)))
          else Icon(Icons.category_outlined,color:blue,size:compact?32:42),
          const SizedBox(height:6),
          Text('${c['name']}',maxLines:2,overflow:TextOverflow.ellipsis,textAlign:TextAlign.center,style:const TextStyle(fontSize:10,fontWeight:FontWeight.w700,color:ink)),
        ]),
      ),
    );
  }

  Widget categoriesPage()=>Column(children:[
    topBar(),
    const Padding(padding:EdgeInsets.fromLTRB(16,4,16,14),child:Align(alignment:Alignment.centerRight,child:Text('همه دسته‌بندی‌ها',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:ink)))),
    Expanded(child: loading?const Center(child:CircularProgressIndicator()):error!=null?errorPanel():GridView.builder(
      padding:const EdgeInsets.all(12),itemCount:categories.length,
      gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,mainAxisSpacing:10,crossAxisSpacing:10,childAspectRatio:.82),
      itemBuilder:(_,i)=>categoryTile(categories[i]),
    )),
  ]);

  Widget productCard(Map<String,dynamic> p) {
    final img='${p['image']??''}';
    final sale='${p['sale_price']??''}'.isNotEmpty && '${p['sale_price']}'!='0';
    final shownPrice=sale?p['sale_price']:p['price'];
    return Material(
      color:Colors.white,borderRadius:BorderRadius.circular(18),
      child: InkWell(borderRadius:BorderRadius.circular(18),onTap:()=>showProduct(p),
        child:Padding(padding:const EdgeInsets.all(9),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          Expanded(child:Stack(children:[
            Positioned.fill(child:img.isEmpty?const Icon(Icons.image_not_supported_outlined,color:Colors.black26,size:45):Image.network(img,fit:BoxFit.contain,errorBuilder:(_,__,___)=>const Icon(Icons.image_not_supported_outlined,color:Colors.black26,size:45))),
            if(sale) const Positioned(top:0,right:0,child:Chip(label:Text('تخفیف',style:TextStyle(color:Colors.white,fontSize:9)),backgroundColor:Color(0xFFE5484D),padding:EdgeInsets.zero,visualDensity:VisualDensity.compact)),
          ])),
          const SizedBox(height:7),
          SizedBox(height:38,child:Text('${p['name']??''}',maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:11,fontWeight:FontWeight.w700,color:ink))),
          const SizedBox(height:6),
          Text(price(shownPrice),maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:blue,fontSize:11,fontWeight:FontWeight.w900)),
          const SizedBox(height:8),
          SizedBox(height:34,child:FilledButton(onPressed:()=>add(p),style:FilledButton.styleFrom(padding:EdgeInsets.zero,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(11))),child:const Text('افزودن به سبد',style:TextStyle(fontSize:10,fontWeight:FontWeight.bold)))),
        ])),
      ),
    );
  }

  void showProduct(Map<String,dynamic> p) {
    showModalBottomSheet(context:context,isScrollControlled:true,backgroundColor:Colors.transparent,builder:(ctx)=>Directionality(textDirection:TextDirection.rtl,child:Container(
      height:MediaQuery.of(ctx).size.height*.78,padding:const EdgeInsets.all(18),
      decoration:const BoxDecoration(color:Colors.white,borderRadius:BorderRadius.vertical(top:Radius.circular(24))),
      child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Align(alignment:Alignment.centerLeft,child:IconButton(onPressed:()=>Navigator.pop(ctx),icon:const Icon(Icons.close))),
        Expanded(child:Image.network('${p['image']??''}',fit:BoxFit.contain,errorBuilder:(_,__,___)=>const Icon(Icons.image_not_supported_outlined,size:70,color:muted))),
        const SizedBox(height:12),
        Text('${p['name']??''}',style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900,color:ink)),
        const SizedBox(height:10),
        Text(price(p['sale_price']??p['price']),style:const TextStyle(fontSize:18,color:blue,fontWeight:FontWeight.w900)),
        const SizedBox(height:14),
        FilledButton(onPressed:(){Navigator.pop(ctx);add(p);},child:const Text('افزودن به سبد خرید')),
      ]),
    )));
  }

  Widget cartPage()=>Column(children:[
    topBar(),
    const Padding(padding:EdgeInsets.all(16),child:Align(alignment:Alignment.centerRight,child:Text('سبد خرید شما',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:ink)))),
    Expanded(child:cart.isEmpty?const Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.shopping_bag_outlined,size:60,color:Color(0xFF98A2B3)),SizedBox(height:12),Text('سبد خرید شما خالی است',style:TextStyle(color:muted,fontWeight:FontWeight.w700))])):ListView.builder(itemCount:cart.length,itemBuilder:(_,i){
      final p=cart[i];return Card(color:Colors.white,margin:const EdgeInsets.symmetric(horizontal:14,vertical:5),child:ListTile(title:Text('${p['name']}',maxLines:2,overflow:TextOverflow.ellipsis),subtitle:Text(price(p['price'])),trailing:IconButton(onPressed:()=>setState(()=>cart.removeAt(i)),icon:const Icon(Icons.delete_outline,color:Colors.red))));
    })),
    if(cart.isNotEmpty)Padding(padding:const EdgeInsets.all(16),child:SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('اتصال ثبت سفارش و پرداخت در مرحله بعد پیاده‌سازی می‌شود'))),child:const Text('ادامه و ثبت سفارش')))),
  ]);

  Widget accountPage()=>Column(children:[
    topBar(),
    const SizedBox(height:20),
    CircleAvatar(radius:38,backgroundColor:const Color(0xFFE8EEFF),child:const Icon(Icons.person_outline,size:42,color:blue)),
    const SizedBox(height:12),
    const Text('حساب کاربری من',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:ink)),
    const SizedBox(height:5),
    const Text('برای مشاهده سفارش‌ها وارد حساب خود شوید',style:TextStyle(fontSize:11,color:muted)),
    const SizedBox(height:18),
    Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Column(children:[
      accountItem(Icons.receipt_long_outlined,'سفارش‌های من'),
      accountItem(Icons.location_on_outlined,'آدرس‌های من'),
      accountItem(Icons.favorite_border,'علاقه‌مندی‌ها'),
      accountItem(Icons.support_agent,'پشتیبانی و تماس با ما'),
    ])),
  ]);

  Widget accountItem(IconData icon,String title)=>Card(color:Colors.white,elevation:0,child:ListTile(leading:Icon(icon,color:blue),title:Text(title,style:const TextStyle(fontSize:13,fontWeight:FontWeight.w700)),trailing:const Icon(Icons.chevron_left)));

  Widget errorPanel()=>Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[
    const Icon(Icons.cloud_off_outlined,size:48,color:muted),
    const SizedBox(height:12),
    Text(error??'خطا در دریافت اطلاعات',textAlign:TextAlign.center),
    const SizedBox(height:12),
    FilledButton.icon(onPressed:loadStore,icon:const Icon(Icons.refresh),label:const Text('تلاش دوباره')),
  ])));
}
